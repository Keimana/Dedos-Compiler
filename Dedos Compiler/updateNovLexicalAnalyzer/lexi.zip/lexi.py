class DEDOSLexicalAnalyzer:
    def __init__(self):
        # Reserved Words (Keywords)
        self.reserved_words = {
            "~{": "START_PROGRAM", "}~": "END_PROGRAM", "inst": "INST_TOKEN", "flank": "FLANK_TOKEN", 
            "strike": "STRIKE_TOKEN", "tool": "_TOOL", "chat": "CHAT_TOKEN", "info": "IDENTIFIER_INFO", 
            "plant": "PLANT_TOKEN", "re": "RE_TOKEN", "load": "LOAD_TOKEN", "reload": "RELOAD_TOKEN", 
            "force": "FORCE_TOKEN", "watch": "WATCH_TOKEN", "abort": "ABORT_TOKEN", "push": "PUSH_TOKEN", 
            "in": "IDENTIFIER_IN", "not": "NOT_TOKEN", "or": "OR_TOKEN", "and": "AND_TOKEN", 
            "pos": "IDENTIFIER_POS", "neg": "IDENTIFIER_NEG", "defuse": "DEFUSE_TOKEN", "globe": "GLOBE_TOKEN", 
            "back": "RETURN_TOKEN", "bounce": "BOUNCE_TOKEN", "perim": "RANGE_TOKEN"
        }

        # Operators
        self.operators = {"+", "-", "*", "/", "%", "**", "//", "=", "==", "!=", ">", "<", ">=", "<="}
        self.delimiters = {"~{", "}~","{", "}", "(", ")", "[", "]", ";", ","}

    def a_token(self, token):
        state = 0  # Initial state
        for char in token:
            if state == 0:
                if char == 'a':
                    state = 1  # Move to the next state after 'a'
                else:
                    break  # Not a valid token starting with 'a'

            elif state == 1:
                if char == 'b':
                    state = 2  # 'ab'
                elif char == 'n':
                    state = 3  # 'an'
                else:
                    break  # Invalid keyword
                    
            elif state == 2:
                if char == 'o':
                    state = 4  # 'abo'
                else:
                    break

            elif state == 3:
                if char == 'd':
                    state = 5  # 'and'
                else:
                    break

            elif state == 4:
                if char == 'r':
                    state = 6  # 'abor'
                else:
                    break

            elif state == 6:
                if char == 't':
                    state = 7  # 'abort'
                else:
                    break

        # Final states to check exact matches:
        if state == 7 and len(token) == 5:  # 'abort' with exact length
            return "ABORT_TOKEN"
        elif state == 5 and len(token) == 3:  # 'and' with exact length
            return "AND_TOKEN"
        else:
            return "IDENTIFIER"


    def b_token(self, token):
        state = 0  # Initial state
        for char in token:
            if state == 0:
                if char == 'b':
                    state = 1  # Move to the next state after 'b'
                else:
                    break  # Invalid token
                    
            elif state == 1:
                if char == 'a':
                    state = 2  # 'ba'
                elif char == 'o':
                    state = 3  # 'bo'
                else:
                    break

            elif state == 2:
                if char == 'c':
                    state = 4  # 'bac'
                else:
                    break

            elif state == 3:
                if char == 'u':
                    state = 5  # 'bou'
                else:
                    break

            elif state == 4:
                if char == 'k':
                    state = 6  # 'back'
                else:
                    break

            elif state == 5:
                if char == 'n':
                    state = 7  # 'boun'
                else:
                    break

            elif state == 7:
                if char == 'c':
                    state = 8  # 'bounc'
                else:
                    break

            elif state == 8:
                if char == 'e':
                    state = 9  # 'bounce'
                else:
                    break

        # Final states to check exact matches:
        if state == 6 and len(token) == 4:  # 'back' with exact length
            return "BACK_TOKEN"
        elif state == 9 and len(token) == 6:  # 'bounce' with exact length
            return "BOUNCE_TOKEN"
        else:
            return "IDENTIFIER"


    def c_token(self, token):
        state = 0  # Initial state

        for char in token:
            if state == 0:
                if char == 'c':
                    state = 1  # Transition to state 1 after 'c'
                else:
                    break  # Invalid token if not starting with 'c'
            
            elif state == 1:
                if char == 'h':  # After 'c', we expect 'h'
                    state = 2
                else:
                    break  # Invalid if not 'h' after 'c'

            elif state == 2:
                if char == 'a':  # After 'ch', we expect 'a'
                    state = 3
                else:
                    break  # Invalid if not 'a' after 'ch'

            elif state == 3:
                if char == 't':  # After 'cha', we expect 't'
                    state = 4  # Transition to final state
                else:
                    break  # Invalid if not 't' after 'cha'

        # Final state for 'chat'
        if state == 4 and len(token) == 4:  # 'chat' with exact length
            return "CHAT_TOKEN"  # Recognized 'chat' as a valid token
        else:
            return "IDENTIFIER"  # Invalid token if not exactly 'chat'

            
    def d_token(self, token):
        state = 0  # Initial state

        for char in token:
            if state == 0:
                if char == 'd':
                    state = 1  # Transition to state 1 after 'd'
                else:
                    break  # Invalid token if not starting with 'd'
            
            elif state == 1:
                if char == 'e':  # After 'd', we expect 'e'
                    state = 2
                else:
                    break  # Invalid if not 'e' after 'd'

            elif state == 2:
                if char == 'f':  # After 'de', we expect 'f'
                    state = 3
                else:
                    break  # Invalid if not 'f' after 'de'

            elif state == 3:
                if char == 'u':  # After 'def', we expect 'u'
                    state = 4
                else:
                    break  # Invalid if not 'u' after 'def'

            elif state == 4:
                if char == 's':  # After 'defu', we expect 's'
                    state = 5
                else:
                    break  # Invalid if not 's' after 'defu'

            elif state == 5:
                if char == 'e':  # After 'defus', we expect 'e'
                    state = 6  # Transition to final state
                else:
                    break  # Invalid if not 'e' after 'defus'

        # Final state for 'defuse'
        if state == 6 and len(token) == 6:  # 'defuse' with exact length
            return "DEFUSE_TOKEN"  # Recognized 'defuse' as a valid token
        else:
            return "IDENTIFIER"  # Invalid token if not exactly 'defuse'
        

    def f_token(self, token):
        state = 0  # Initial state

        for char in token:
            if state == 0:
                if char == 'f':
                    state = 1  # Move to the next state after 'f'
                else:
                    break  # Invalid token if not starting with 'f'
                
            elif state == 1:
                if char == 'l':
                    state = 2  # 'fl'
                elif char == 'o':
                    state = 3  # 'fo'
                else:
                    break

            elif state == 2:
                if char == 'a':
                    state = 4  # 'fla'
                else:
                    break

            elif state == 3:
                if char == 'r':
                    state = 5  # 'for'
                else:
                    break

            elif state == 4:
                if char == 'n':
                    state = 6  # 'flan'
                else:
                    break

            elif state == 5:
                if char == 'c':
                    state = 7  # 'forc'
                else:
                    break

            elif state == 6:
                if char == 'k':
                    state = 8  # 'flank'
                else:
                    break

            elif state == 7:
                if char == 'e':
                    state = 9  # 'force'
                else:
                    break

        # Final states for exact strings
        if state == 8 and len(token) == 5:  # 'flank' with exact length
            return "FLANK_TOKEN"
        elif state == 9 and len(token) == 5:  # 'force' with exact length
            return "FORCE_TOKEN"
        else:
            return "IDENTIFIER"  # Invalid token if not exactly 'flank' or 'force'



    def g_token(self, token):
        state = 0  # Initial state

        for char in token:
            if state == 0:
                if char == 'g':
                    state = 1  # Move to the next state after 'g'
                else:
                    break  # Invalid token if not starting with 'g'
                    
            elif state == 1:
                if char == 'l':
                    state = 2  # 'gl'
                else:
                    break

            elif state == 2:
                if char == 'o':
                    state = 3  # 'glo'
                else:
                    break

            elif state == 3:
                if char == 'b':
                    state = 4  # 'glob'
                else:
                    break

            elif state == 4:
                if char == 'e':
                    state = 5  # 'globe'
                else:
                    break

        # Final state with exact length check
        if state == 5 and len(token) == 5:  # 'globe' with exact length
            return "GLOBE_TOKEN"
        else:
            return "IDENTIFIER"  # Invalid token if not exactly 'globe'


    def i_token(self, token):
        # Handle exact matches for the keywords
        if token == "inst":
            return "INST_TOKEN"  # Recognize 'inst' as INST_TOKEN

        # Reject any token starting with 'ins' but not exactly 'inst'
        if len(token) > 3 and token[:3] == 'ins':
            return "IDENTIFIER"  # Anything starting with 'ins' and not exactly 'inst' is an identifier

        # Handle exact matches for 'in' and 'info'
        if token == "in":
            return "IN_TOKEN"  # Recognize 'in' as IN_TOKEN
        elif token == "info":
            return "INFO_TOKEN"  # Recognize 'info' as INFO_TOKEN

        # State machine for tokens starting with 'i'
        state = 0  # Initial state
        for idx, char in enumerate(token):
            if state == 0:
                if char == 'i':
                    state = 1  # Move to the next state after 'i'
                else:
                    break  # Invalid token

            elif state == 1:
                if char == 'n':
                    state = 2  # 'in'
                elif char == 's':
                    state = 3  # 'is'
                elif char == 'f':
                    state = 5  # 'info'
                else:
                    break

            elif state == 2:
                if idx == 1:  # 'in' ends here, only two characters
                    return "IN_TOKEN"  # Return 'IN_TOKEN' for 'in'
                elif char == 's':
                    state = 4  # 'inst'
                else:
                    break

            elif state == 3:
                if char == 't':
                    state = 4  # 'inst'
                else:
                    break

            elif state == 4:
                if idx == 3:  # 'inst' ends here, exactly 4 characters
                    return "INST_TOKEN"  # Return 'INST_TOKEN' for 'inst'
                else:
                    break

            elif state == 5:
                if char == 'o':
                    state = 6  # 'fo' in 'info'
                else:
                    break

            elif state == 6:
                if char == 'r':
                    state = 7  # 'for' in 'info'
                else:
                    break

            elif state == 7:
                if char == 'm':
                    state = 8  # 'info' complete
                else:
                    break

            elif state == 8:
                if idx == 3:  # 'info' ends here, exactly 4 characters
                    return "INFO_TOKEN"  # Return 'INFO_TOKEN' for 'info'
                else:
                    break

        # If the token is longer than expected or doesn't match the exact keywords, return IDENTIFIER
        return "IDENTIFIER"

    def l_token(self, token):
        state = 0  # Initial state
        for char in token:
            if state == 0:
                if char == 'l':
                    state = 1  # Move to the next state after 'l'
                else:
                    break  # Invalid token
                
            elif state == 1:
                if char == 'o':
                    state = 2  # 'lo'
                else:
                    break

            elif state == 2:
                if char == 'a':
                    state = 3  # 'loa'
                else:
                    break

            elif state == 3:
                if char == 'd':
                    state = 4  # 'load'
                else:
                    break

        # Ensure only exact match for 'load'
        if state == 4 and len(token) == 4:  # Only accept exactly 'load'
            return "LOAD_TOKEN"
        else:
            return "IDENTIFIER"


    def n_token(self, token):
        state = 0  # Initial state
        for char in token:
            if state == 0:
                if char == 'n':
                    state = 1  # Move to the next state after 'n'
                else:
                    break  # Invalid token

            elif state == 1:
                if char == 'o':
                    state = 2  # 'no'
                elif char == 'e':
                    state = 4  # 'neg'
                else:
                    break

            elif state == 2:
                if char == 't':
                    state = 3  # 'not'
                else:
                    break

            elif state == 4:
                if char == 'g':
                    state = 5  # 'neg' complete
                else:
                    break

        # Ensure exact matches for 'not' and 'neg'
        if state == 3 and len(token) == 3:  # 'not' is exactly 3 characters
            return "NOT_TOKEN"
        elif state == 5 and len(token) == 3:  # 'neg' is exactly 3 characters
            return "NEG_TOKEN"
        else:
            return "IDENTIFIER"



    def o_token(self, token):

        state = 0  # Initial state
        for char in token:
            if state == 0:
                if char == 'o':
                    state = 1  # Move to the next state after 'o'
                else:
                    break  # Invalid token

            elif state == 1:
                if char == 'r':
                    state = 2  # 'or'
                else:
                    break

        # Final states
        if state == 2 and len(token) == 2:  # Ensure token is exactly "or"
            return "OR_TOKEN"
        else:
            return "IDENTIFIER"



    def p_token(self, token):
        state = 0  # Initial state
        for char in token:
            if state == 0:
                if char == 'p':
                    state = 1  # Move to the next state after 'p'
                else:
                    break  # Invalid token

            elif state == 1:
                if char == 'o':
                    state = 2  # 'po'
                elif char == 'l':
                    state = 5  # 'pl'
                elif char == 'e':
                    state = 8  # 'pe'
                else:
                    break

            elif state == 2:
                if char == 's':
                    state = 3  # 'pos'
                else:
                    break

            elif state == 3:
                if len(token) == 3:  # Ensure the token length is exactly 3 for 'pos'
                    return "POS_TOKEN"  # Return 'POS_TOKEN' for 'pos'
                else:
                    break  # If the token length is longer than 'pos', break out of the loop

            elif state == 5:
                if char == 'a':
                    state = 6  # 'pla'
                else:
                    break

            elif state == 6:
                if char == 'n':
                    state = 7  # 'plan'
                else:
                    break

            elif state == 7:
                if char == 't':
                    state = 10  # 'plant'
                else:
                    break

            elif state == 8:
                if char == 'r':
                    state = 9  # 'per'
                else:
                    break

            elif state == 9:
                if char == 'i':
                    state = 11  # 'peri'
                else:
                    break

            elif state == 11:
                if char == 'm':
                    state = 12  # 'perim'
                else:
                    break

        # Final states
        if state == 3 and len(token) == 3:  # 'pos' ends here and token length is valid
            return "POS_TOKEN"  # Return 'POS_TOKEN' for 'pos'
        elif state == 10 and len(token) == 5:  # 'plant' ends here and token length is valid
            return "PLANT_TOKEN"
        elif state == 12 and len(token) == 5:  # 'perim' ends here and token length is valid
            return "PERIM_TOKEN"
        else:
            return "IDENTIFIER"  # Default fallback to IDENTIFIER



    def r_token(self, token):
        state = 0  # Initial state
        for char in token:
            if state == 0:
                if char == 'r':
                    state = 1  # Move to the next state after 'r'
                else:
                    break  # Invalid token

            elif state == 1:
                if char == 'e':
                    state = 2  # 're'
                elif char == 'l':
                    state = 5  # 'rl'
                else:
                    break

            elif state == 2:
                if len(token) == 2:  # Ensure token length is 2 for 're'
                    return "RE_TOKEN"  # Return 'RE_TOKEN' for 're'
                elif char == 'l':
                    state = 3  # 'rel'
                else:
                    break

            elif state == 3:
                if char == 'o':
                    state = 4  # 'relo'
                else:
                    break

            elif state == 4:
                if char == 'a':
                    state = 5  # 'reloa'
                else:
                    break

            elif state == 5:
                if char == 'd':
                    state = 6  # 'reload'
                else:
                    break

        # Final states
        if state == 2 and len(token) == 2:  # 're' ends here and token length is valid
            return "RE_TOKEN"  # Return 'RE_TOKEN' for 're'
        elif state == 6 and len(token) == 6:  # 'reload' ends here and token length is valid
            return "RELOAD_TOKEN"  # Return 'LOAD_TOKEN' for 'reload'
        else:
            return "IDENTIFIER"  # Default fallback to IDENTIFIER



    def s_token(self, token):
        state = 0  # Initial state
        for idx, char in enumerate(token):
            if state == 0:
                if char == 's':
                    state = 1  # Move to the next state after 's'
                else:
                    break  # Invalid token

            elif state == 1:
                if char == 't':
                    state = 2  # 'st'
                else:
                    break

            elif state == 2:
                if char == 'r':
                    state = 3  # 'str'
                else:
                    break

            elif state == 3:
                if char == 'i':
                    state = 4  # 'stri'
                else:
                    break

            elif state == 4:
                if char == 'k':
                    state = 5  # 'strik'
                else:
                    break

            elif state == 5:
                if char == 'e':
                    state = 6  # 'strike'
                else:
                    break

        # Final states
        if state == 6 and len(token) == 6:  # Ensure the token length is exactly 6 for 'strike'
            return "STRIKE_TOKEN"  # Return 'STRIKE_TOKEN' for 'strike'
        else:
            return "IDENTIFIER"  # Default fallback to IDENTIFIER



    def t_token(self, token):
        state = 0  # Initial state
        for idx, char in enumerate(token):
            if state == 0:
                if char == 't':
                    state = 1  # Move to the next state after 't'
                else:
                    break  # Invalid token

            elif state == 1:
                if char == 'o':
                    state = 2  # 'to'
                else:
                    break

            elif state == 2:
                if char == 'o':
                    state = 3  # 'too'
                else:
                    break

            elif state == 3:
                if char == 'l':
                    state = 4  # 'tool'
                else:
                    break

        # Final states
        if state == 4 and len(token) == 4:  # Ensure the token length is exactly 4 for 'tool'
            return "TOOL_TOKEN"  # Return 'TOOL_TOKEN' for 'tool'
        else:
            return "IDENTIFIER"  # Default fallback to IDENTIFIER


    def w_token(self, token):
        state = 0  # Initial state
        for idx, char in enumerate(token):
            if state == 0:
                if char == 'w':
                    state = 1  # Move to the next state after 'w'
                else:
                    break  # Invalid token

            elif state == 1:
                if char == 'a':
                    state = 2  # 'wa'
                else:
                    break

            elif state == 2:
                if char == 't':
                    state = 3  # 'wat'
                else:
                    break

            elif state == 3:
                if char == 'c':
                    state = 4  # 'watc'
                else:
                    break

            elif state == 4:
                if char == 'h':
                    state = 5  # 'watch'
                else:
                    break

        # Final states
        if state == 5 and len(token) == 5:  # Ensure the token length is exactly 5 for 'watch'
            return "WATCH_TOKEN"  # Return 'WATCH_TOKEN' for 'watch'
        else:
            return "IDENTIFIER"  # Default fallback to IDENTIFIER

        
    def operator_token(self, token):
        description = ""  # To store the description of the operator

        # Check for invalid tokens like '===' or '+++'
        if len(token) > 2:  
            return (f"Invalid token: {token}", "LEXICAL_ERROR")

        # Handle multi-character operators (e.g., '-=', '+=', '==', '>=', etc.)
        if len(token) == 2:
            if token == "==":
                description = "EQUALITY_TOKEN"
                return (description, "==")
            elif token == "+=":
                description = "PLUSEQUALS_TOKEN"
                return (description, "+=")
            elif token == "-=":
                description = "MINUSEQUALS_TOKEN"
                return (description, "-=")
            elif token == "!=":
                description = "NOTEQUAL_TOKEN"
                return (description, "!=")
            elif token == ">=":
                description = "GREATEREQUAL_TOKEN"
                return (description, ">=")
            elif token == "<=":
                description = "LESSEQUAL_TOKEN"
                return (description, "<=")
            elif token == "/=":
                description = "DIVISIONEQUAL_TOKEN"
                return (description, "/=")
            elif token == "%=":
                description = "MODULOEQUAL_TOKEN"
                return (description, "%=")

        # Handle special multi-character operators (e.g., '**' and '//')
        if len(token) == 2:
            if token == "**":
                description = "EXPONENTIAL_TOKEN"
                return (description, "**")
            elif token == "//":
                description = "FLOOR_TOKEN"
                return (description, "//")

        # Handle single-character operators with exact length matching
        if len(token) == 1:
            if token == "=":
                description = "EQUAL_TOKEN"
                return (description, "=")
            elif token == ">":
                description = "GREATER_TOKEN"
                return (description, ">")
            elif token == "<":
                description = "LESS_TOKEN"
                return (description, "<")
            elif token == "+":
                description = "PLUS_TOKEN"
                return (description, "+")
            elif token == "-":
                description = "MINUS_TOKEN"
                return (description, "-")
            elif token == "*":
                description = "MULTIPLY_TOKEN"
                return (description, "*")
            elif token == "/":
                description = "DIVISION_TOKEN"
                return (description, "/")
            elif token == "%":
                description = "MODULO_TOKEN"
                return (description, "%")

        # Return error for any other invalid operator
        return (f"Invalid token: {token}", "LEXICAL_ERROR")



    def classify_token(self, token):
        # Handle multi-character operators first
        if token in {"==", "!=", ">=", "<=", "-=", "+=", "*=", "/=", "%="}:
            return self.operator_token(token)

        # Handle single-character operators
        if token in {"+", "-", "*", "/", "%", "**", "//"}:
            return self.operator_token(token)
        elif token in {"=", ">", "<"}:
            return self.operator_token(token)

        # Handle spaces
        if token == " ":
            return "SPACE"

        # Handle alphabetic tokens (keywords or identifiers)
        if token.isalpha():
            if token[0] == 'a':
                return self.a_token(token)
            elif token[0] == 'b':
                return self.b_token(token)
            elif token[0] == 'c':
                return self.c_token(token)
            elif token[0] == 'd':
                return self.d_token(token)
            elif token[0] == 'f':
                return self.f_token(token)
            elif token[0] == 'g':
                return self.g_token(token)
            elif token[0] == 'i':
                return self.i_token(token)  # Calling i_token for 'i' prefix tokens
            elif token[0] == 'l':
                return self.l_token(token)
            elif token[0] == 'n':
                return self.n_token(token)
            elif token[0] == 'o':
                return self.o_token(token)
            elif token[0] == 'p':
                return self.p_token(token)
            elif token[0] == 'r':
                return self.r_token(token)
            elif token[0] == 's':
                return self.s_token(token)
            elif token[0] == 't':
                return self.t_token(token)
            elif token[0] == 'w':
                return self.w_token(token)  # Calling w_token for 'w' prefix tokens
            elif token[0] == 'z':
                return self.identifier_token(token)

        # Handle specific types of literals and delimiters
        # Handle digits
        if token.isdigit():
            return {"token_type": "INST_LITERAL", "lexeme": token}

        # Handle string literals
        if token.startswith('"') and token.endswith('"'):
            return {"token_type": "STRIKE_LITERAL", "lexeme": token}
        
        # Handle character literals
        if token.startswith("'") and token.endswith("'"):
            return {"token_type": "CHAT_LITERAL", "lexeme": token}

        # Handle delimiters (including multi-character ones)
        if token in self.delimiters:
            return {"token_type": token, "lexeme": token}

        # Handle operators
        if token in self.operators:
            return {"token_type": token, "lexeme": token}
        # Fallback for unrecognized tokens
        return "IDENTIFIER"

    def tokenize(self, input_string):
        """Tokenizes the input string based on predefined rules using alphabetically split functions."""
        tokens = []
        i = 0
        length = len(input_string)

        while i < length:
            char = input_string[i]

            # Handle multi-character delimiter "~{" and "}~"
            if i + 1 < length and input_string[i:i+2] == "~{":
                tokens.append(("~{", "~{"))
                i += 2  # Skip the next character
                continue
            elif i + 1 < length and input_string[i:i+2] == "}~":
                tokens.append(("}~", "}~"))
                i += 2  # Skip the next character
                continue

            # Handle delimiters, including the comma specifically
            if char in self.delimiters:
                if char == ",":
                    tokens.append(("Comma", ","))
                else:
                    tokens.append((char, char))
                i += 1
                continue
            # Handle whitespace
            if char.isspace():
                tokens.append(("SPACE", "\n"))
                i += 1
                continue

            # Handle multi-character operators (e.g., '+=', '-=', '/=')
            if char in {'-', '+', '/', '%'} and i + 1 < length and input_string[i + 1] == '=':
                operator_token = self.operator_token(input_string[i:i + 2])
                tokens.append(operator_token)
                i += 2
                continue

            # Handle multi-character operators (e.g., '**', '//')
            if char == '*' and i + 1 < length and input_string[i + 1] == '*':
                operator_token = self.operator_token("**")
                tokens.append(operator_token)
                i += 2
                continue
            elif char == '/' and i + 1 < length and input_string[i + 1] == '/':
                operator_token = self.operator_token("//")
                tokens.append(operator_token)
                i += 2
                continue
            elif char == '=' and i + 1 < length and input_string[i + 1] == '=':
                operator_token = self.operator_token("==")
                tokens.append(operator_token)
                i += 2
                continue

            # Handle single-character operators (e.g., '-', '+', '*', '/', '%')
            if char in {'-', '+', '*', '/', '%'}:
                if char == "-" and i + 1 < length:
                    next_char = input_string[i + 1]

                    # Handle negative numbers (integers or floats)
                    if next_char.isdigit() or next_char == '.':  # Negative number case
                        start = i
                        i += 1  # Skip the minus sign and include it with the number
                        while i < length and (input_string[i].isdigit() or input_string[i] == '.'):
                            i += 1
                        # Ensure the token is identified correctly as a float or integer
                        if '.' in input_string[start:i]:
                            tokens.append(("FLOAT_LITERAL", input_string[start:i]))  # Add the full float literal
                        else:
                            tokens.append(("INST_LITERAL", input_string[start:i]))  # Add the full integer literal
                        continue

                operator_token = self.operator_token(input_string[i:i + 1])
                tokens.append(operator_token)
                i += 1
                continue

            # Handle comparison operators (e.g., '=', '>', '<')
            if char in {'=', '>', '<'}:
                operator_token = self.operator_token(input_string[i:i + 1])
                tokens.append(operator_token)
                i += 1
                continue

            # Handle identifiers or reserved words
            if char.isalpha():
                start = i
                while i < length and (input_string[i].isalnum() or input_string[i] == "_"):
                    i += 1
                token = input_string[start:i]
                token_type = self.classify_token(token)
                tokens.append((token_type, token))
                continue

            # Handle numbers (integer or float, including negative)
            if char.isdigit() or (char == "-" and i + 1 < length and (input_string[i + 1].isdigit() or input_string[i + 1] == ".")):
                start = i
                if char == "-":
                    i += 1  # Skip the minus sign and include it with the number

                # Handle digits of the number
                while i < length and input_string[i].isdigit():
                    i += 1

                # Handle decimal point for float (check if decimal point exists after digits)
                if i < length and input_string[i] == ".":
                    i += 1  # Skip the decimal point
                    # If digits follow the decimal point, continue parsing
                    while i < length and input_string[i].isdigit():
                        i += 1
                    tokens.append(("FLOAT_LITERAL", input_string[start:i]))  # Add the full float literal
                else:
                    tokens.append(("INST_LITERAL", input_string[start:i]))  # Add the full integer literal
                continue

            # Handle multi-line comments
            if input_string[i:i + 3] == "^^^":
                start = i
                i += 3  # Skip the opening ^^^
                while i < length and input_string[i:i + 3] != "^^^":
                    i += 1
                if i < length and input_string[i:i + 3] == "^^^":
                    i += 3  # Skip the closing ^^^
                    tokens.append(("MULTI_LINE_COMMENT_TOKEN", input_string[start:i]))
                else:
                    tokens.append(("ERROR", "Unterminated multi-line comment"))
                continue

            # Handle single-line comments
            if input_string[i:i + 2] == "^^":
                start = i
                i += 2  # Skip the opening ^^
                while i < length and input_string[i:i + 2] != "^^":
                    i += 1
                if i < length and input_string[i:i + 2] == "^^":
                    i += 2  # Skip the closing ^^
                    tokens.append(("SINGLE_LINE_COMMENT_TOKEN", input_string[start:i]))
                else:
                    tokens.append(("ERROR", "Unterminated single-line comment"))
                continue

            # Handle string literals
            if char == '"':
                start = i
                i += 1
                while i < length and input_string[i] != '"':
                    i += 1
                if i < length:
                    i += 1
                    tokens.append(("STRIKE_LITERAL", input_string[start:i]))
                else:
                    tokens.append(("ERROR", "Unterminated string literal"))
                continue

            if char == "'":
                start = i
                i += 1
                while i < length and input_string[i] != "'":
                    i += 1
                if i < length:
                    i += 1
                    tokens.append(("CHAT_LITERAL", input_string[start:i]))
                else:
                    tokens.append(("ERROR", "Unterminated string literal"))
                continue

            # Handle unknown characters and transition to the next state
            tokens.append(("UNKNOWN", char))
            i += 1

        return tokens
