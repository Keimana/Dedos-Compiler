import tkinter as tk
from tkinter import scrolledtext
from lexi import DEDOSLexicalAnalyzer

def analyze_code():
    user_input = code_input.get("1.0", tk.END).strip()

    if not user_input:
        result_output.delete(1.0, tk.END)
        result_output.insert(tk.END, "No input provided. Please enter valid DEDOS code.")
        return

    # Create an instance of the lexical analyzer
    lexer = DEDOSLexicalAnalyzer()

    try:
        # Tokenize the user's input
        tokens = lexer.tokenize(user_input)

        # Check if tokens are valid and non-empty
        if not tokens:
            result_output.delete(1.0, tk.END)
            result_output.insert(tk.END, "Error: No tokens generated. Please check your input.")
            return

        # Populate the lexeme and token columns on the right side
        lexeme_list.delete(0, tk.END)
        token_list.delete(0, tk.END)

        for token_type, lexeme in tokens:
            lexeme_list.insert(tk.END, lexeme)
            token_list.insert(tk.END, token_type)

    except Exception as e:
        # Handle unexpected errors during tokenization
        result_output.delete(1.0, tk.END)
        result_output.insert(tk.END, f"An error occurred during lexical analysis:\n{e}")

def update_line_numbers(event=None):
    # Get the current text in the code_input box
    content = code_input.get("1.0", "end-1c")
    lines = content.split("\n")
    
    # Update the line numbers list
    line_numbers.delete(1.0, tk.END)  # Clear current line numbers
    for i in range(1, len(lines) + 1):
        line_numbers.insert(tk.END, f"{i}\n")

# Create the main window (root)
root = tk.Tk()
root.title("DEDOS Lexical Analyzer")

# Set dark mode theme
root.configure(bg="#333333")

# Configure rows and columns to expand properly with resizing
root.grid_rowconfigure(0, weight=0)  # Row for the input section
root.grid_rowconfigure(1, weight=3)  # Row for the result section
root.grid_rowconfigure(2, weight=0)  # Row for the Analyze button
root.grid_rowconfigure(3, weight=4)  # Row for the lexeme/token listboxes

root.grid_columnconfigure(0, weight=3)  # Column for the input area
root.grid_columnconfigure(1, weight=1)  # Column for lexeme section
root.grid_columnconfigure(2, weight=1)  # Column for token section
root.grid_columnconfigure(3, weight=3)  # Column for results

# Create a label and text box for the user to input DEDOS code
input_label = tk.Label(root, text="Enter DEDOS Code:", bg="#333333", fg="white", font=("Arial", 12))
input_label.grid(row=0, column=0, padx=20, pady=10, sticky="nsew")

# Create a frame to hold both the line numbers and code input text box
input_frame = tk.Frame(root, bg="#333333")
input_frame.grid(row=1, column=0, padx=20, pady=5, sticky="nsew")

# Create a text box to display line numbers
line_numbers = tk.Text(input_frame, width=4, bg="#1e1e1e", fg="white", font=("Arial", 12), bd=0, height=10)
line_numbers.pack(side=tk.LEFT, fill=tk.Y)

# Create a scrolled text box for the code input
code_input = scrolledtext.ScrolledText(input_frame, bg="#1e1e1e", fg="white", insertbackground="white", font=("Arial", 12))
code_input.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

# Bind the <KeyRelease> event to update the line numbers as user types
code_input.bind("<KeyRelease>", update_line_numbers)

# Create a button to trigger the lexical analysis
analyze_button = tk.Button(root, text="Analyze", command=analyze_code, bg="#007acc", fg="white", relief="flat", font=("Arial", 10))
analyze_button.grid(row=2, column=0, padx=1, pady=10, sticky="nsew")

# Create labels for the lexeme and token columns
lexeme_label = tk.Label(root, text="Lexeme", bg="#333333", fg="white", font=("Arial", 12))
lexeme_label.grid(row=0, column=1, padx=10, pady=5, sticky="nsew")
token_label = tk.Label(root, text="Token", bg="#333333", fg="white", font=("Arial", 12))
token_label.grid(row=0, column=2, padx=10, pady=10, sticky="nsew")

# Create lists for lexemes and tokens
lexeme_list = tk.Listbox(root, bg="#1e1e1e", fg="white", font=("Arial", 10))
lexeme_list.grid(row=1, column=1, padx=10, pady=5, sticky="nsew")

token_list = tk.Listbox(root, bg="#1e1e1e", fg="white", font=("Arial", 10))
token_list.grid(row=1, column=2, padx=10, pady=5, sticky="nsew")

# Create the lexical analysis result section (no frame)
result_output = scrolledtext.ScrolledText(root, bg="#1e1e1e", fg="white", insertbackground="white", font=("Arial", 10))
result_output.grid(row=3, column=0, padx=6, pady=10, columnspan=3, sticky="nsew")

# Make the window content expand and center
root.grid_rowconfigure(3, weight=4)  # Adjust the last row to be more flexible
root.grid_columnconfigure(0, weight=4, minsize=80)  # Ensure input area expands
root.grid_columnconfigure(3, weight=4, minsize=80)  # Ensure results section expands

# Start the Tkinter main loop
root.mainloop()
